package com.abcis.abcisexam.service.employee;

import com.abcis.abcisexam.dao.EmployeeRepository;
import com.abcis.abcisexam.entity.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * @author jackrosios
 */
@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    EmployeeRepository employeeRepository;

    @Override
    public List<Employee> getEmployeeList() {
        return employeeRepository.findAll();
    }

    @Override
    public Optional<Employee> getEmployeeById(int id) {
        return employeeRepository.findById(id);
    }

    @Override
    public Employee saveEmployee(Employee employee) {
        return employeeRepository.save(employee);
    }

    @Override
    public Employee updateEmployeeById(int id, Employee employee) {
        Employee updatedEmployee = new Employee();
        updatedEmployee.setId(id);
        updatedEmployee.setBirthDate(employee.getBirthDate());
        updatedEmployee.setFirstName(employee.getFirstName());
        updatedEmployee.setLastName(employee.getLastName());
        updatedEmployee.setGender(employee.getGender());
        updatedEmployee.setHireDate(employee.getHireDate());
        updatedEmployee.setCompany(employee.getCompany());
        return employeeRepository.save(updatedEmployee);
    }

    @Override
    public void deleteEmployeeById(int id) {
        employeeRepository.deleteById(id);
    }
}

