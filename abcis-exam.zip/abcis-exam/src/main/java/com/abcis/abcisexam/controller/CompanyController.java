package com.abcis.abcisexam.controller;

import com.abcis.abcisexam.entity.Company;
import com.abcis.abcisexam.service.company.CompanyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

/**
 * @author jackrosios
 */
@RestController
@RequestMapping(value = "/company")
public class CompanyController {

    @Autowired
    private CompanyService companyService;

    @GetMapping(value = "/list")
    public ResponseEntity<List<Company>> getCompanyList(){
        List<Company> companyList = companyService.getCompanyList();
        return new ResponseEntity<>(companyList, HttpStatus.OK);
    }

    @GetMapping(value = "/{id}")
    public ResponseEntity<Company> getCompanyById(@PathVariable("id") int id){
        Optional<Company> company = companyService.getCompanyById(id);
        if(company.isPresent()){
            return new ResponseEntity<>(company.get(), HttpStatus.OK);
        }
        // ID not exist, no data fetched
        System.out.println("ID is Not Exist to Retrieve!");
        return new ResponseEntity<>(new Company(), HttpStatus.OK);
    }

    @PostMapping(value = "/save")
    public ResponseEntity<Company> saveCompany(@RequestBody Company company){
        Company newCompany = companyService.saveCompany(company);
        return new ResponseEntity<>(newCompany, HttpStatus.OK);
    }

    @PostMapping(value = "/update/{id}")
    public ResponseEntity<Company> saveCompany(@PathVariable("id") int id, @RequestBody Company company){
        Optional<Company> getCompany = companyService.getCompanyById(id);
        if(getCompany.isPresent()) {
            Company updatedCompany = companyService.updateCompanyById(id,company);
            return new ResponseEntity<>(updatedCompany, HttpStatus.OK);
        }
        // ID not exist, no data updated
        System.out.println("Company ID is Not Exist to Update!");
        return new ResponseEntity<>(new Company(), HttpStatus.OK);
    }

    @DeleteMapping(value = "/{id}")
    public ResponseEntity<String> deleteCompany(@PathVariable("id") int id){
       companyService.deleteCompanyById(id);
        return new ResponseEntity<>("Company Record "+id+" is successfully deleted!", HttpStatus.OK);
    }

}
