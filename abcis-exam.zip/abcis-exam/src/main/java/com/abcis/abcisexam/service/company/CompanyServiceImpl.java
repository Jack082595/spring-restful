package com.abcis.abcisexam.service.company;

import com.abcis.abcisexam.dao.CompanyRepository;
import com.abcis.abcisexam.entity.Company;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * @author jackrosios
 */
@Service
public class CompanyServiceImpl implements CompanyService{

    @Autowired
    private CompanyRepository companyRepository;

    @Override
    public List<Company> getCompanyList() {
        return companyRepository.findAll();
    }

    @Override
    public Optional<Company> getCompanyById(int id) {
        return companyRepository.findById(id);
    }

    @Override
    public Company saveCompany(Company company) {
        return companyRepository.save(company);
    }

    @Override
    public Company updateCompanyById(int id, Company company) {
        Company updatedCompany = new Company();
        updatedCompany.setId(id);
        updatedCompany.setCompanyName(company.getCompanyName());
        updatedCompany.setAddress(company.getAddress());
        updatedCompany.setCity(company.getCity());
        updatedCompany.setPhoneNumber(company.getPhoneNumber());
        updatedCompany.setState(company.getState());
        updatedCompany.setZipCode(company.getZipCode());
        return companyRepository.save(updatedCompany);
    }


    @Override
    public void deleteCompanyById(int id) {
        companyRepository.deleteById(id);
    }
}
