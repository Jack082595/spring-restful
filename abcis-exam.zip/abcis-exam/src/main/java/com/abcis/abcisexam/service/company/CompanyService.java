package com.abcis.abcisexam.service.company;

import com.abcis.abcisexam.entity.Company;

import java.util.List;
import java.util.Optional;

/**
 * @author jackrosios
 */
public interface CompanyService {
    List<Company> getCompanyList();
    Optional<Company> getCompanyById(int id);
    Company saveCompany(Company company);
    Company updateCompanyById(int id, Company company);
    void deleteCompanyById(int id);
}
