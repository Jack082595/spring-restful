package com.abcis.abcisexam.service.employee;

import com.abcis.abcisexam.entity.Employee;

import java.util.List;
import java.util.Optional;

/**
 * @author jackrosios
 */
public interface EmployeeService {
    List<Employee> getEmployeeList();
    Optional<Employee> getEmployeeById(int id);
    Employee saveEmployee(Employee employee);
    Employee updateEmployeeById(int id, Employee employee);
    void deleteEmployeeById(int id);
}
