package com.abcis.abcisexam.dao;

import com.abcis.abcisexam.entity.Company;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * @author jackrosios
 */
@Repository
public interface CompanyRepository extends JpaRepository<Company, Integer> {
}
