package com.abcis.abcisexam.controller;

import com.abcis.abcisexam.entity.Employee;
import com.abcis.abcisexam.service.employee.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

/**
 * @author jackrosios
 */
@RestController
@RequestMapping(value = "/employee")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @GetMapping(value = "/list")
    public ResponseEntity<List<Employee>> getCompanyList(){
        List<Employee> employeeList = employeeService.getEmployeeList();
        return new ResponseEntity<>(employeeList, HttpStatus.OK);
    }

    @GetMapping(value = "/{id}")
    public ResponseEntity<Employee> getEmployeeById(@PathVariable("id") int id){
        Optional<Employee> employee = employeeService.getEmployeeById(id);
        if(employee.isPresent()){
            return new ResponseEntity<>(employee.get(), HttpStatus.OK);
        }
        // ID not exist, no data fetched
        System.out.println("ID is Not Exist to Retrieve!");
        return new ResponseEntity<>(new Employee(), HttpStatus.OK);
    }

    @PostMapping(value = "/save")
    public ResponseEntity<Employee> saveEmployee(@RequestBody Employee employee){
        Employee newEmployee = employeeService.saveEmployee(employee);
        return new ResponseEntity<>(newEmployee, HttpStatus.OK);
    }

    @PostMapping(value = "/update/{id}")
    public ResponseEntity<Employee> saveEmployee(@PathVariable("id") int id, @RequestBody Employee employee){
        Optional<Employee> getEmployee = employeeService.getEmployeeById(id);
        if(getEmployee.isPresent()) {
            Employee updatedEmployee = employeeService.updateEmployeeById(id,employee);
            return new ResponseEntity<>(updatedEmployee, HttpStatus.OK);
        }
        // ID not exist, no data updated
        System.out.println("Employee ID is Not Exist to Update!");
        return new ResponseEntity<>(new Employee(), HttpStatus.OK);
    }

    @DeleteMapping(value = "/{id}")
    public ResponseEntity<String> deleteEmployee(@PathVariable("id") int id){
        employeeService.deleteEmployeeById(id);
        return new ResponseEntity<>("Employee Record "+id+" is successfully deleted!", HttpStatus.OK);
    }
}
