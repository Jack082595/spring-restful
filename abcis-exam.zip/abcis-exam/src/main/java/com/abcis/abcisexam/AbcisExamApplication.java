package com.abcis.abcisexam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AbcisExamApplication {

	public static void main(String[] args) {
		SpringApplication.run(AbcisExamApplication.class, args);
	}

}
